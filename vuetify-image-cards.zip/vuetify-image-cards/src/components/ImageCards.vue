<template>
  <!-- <div>
    <v-card>
      <v-title v-for="(photo, index) in photos"
        :key="index">
        {{ photo.albumId }}
      </v-title>
      <v-card-text v-for="(photo, photoIndex) in photos"
        :key="photoIndex">
        <v-img
        src="{{ photo.url }}"
    ></v-img>
      </v-card-text>
    </v-card>
  </div> -->
   <v-card
    class="mx-auto"
    max-width="400"
  >
    <v-img
      v-for="(photo, index) in photos"
      class="align-end text-white"
      height="200"
      src="{{photo.url}}"
      :key="index"
      cover
    >
      <v-card-title>{{ photo.title }}</v-card-title>
    </v-img>

    <v-card-subtitle class="pt-4">
      Number 10
    </v-card-subtitle>

    <v-card-text>
      <div>Whitehaven Beach</div>

      <div>Whitsunday Island, Whitsunday Islands</div>
    </v-card-text>

    <v-card-actions>
      <v-btn color="orange">
        Share
      </v-btn>

      <v-btn color="orange">
        Explore
      </v-btn>
    </v-card-actions>
  </v-card>
</template>

<script>
export default {
  name: "ImageCards",
  props: {
    photos: {
      type: Array
    }
  }
}
</script>