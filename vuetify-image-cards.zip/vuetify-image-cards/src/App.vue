<template>
  <div>
    <v-container>
      <!-- <v-card> -->
        <v-card-title>
          <div class="d-flex justify-space-between">
            <span>Photo Gallery</span>
            <v-btn color="primary" @click="openDialog">Add Photo</v-btn>
          </div>
        </v-card-title>
        <ImageCards :photos="photos"></ImageCards>
      <!-- </v-card> -->
    </v-container>

    <!--//////////////////////////////////// DIALOG //////////////////////////////////////////-->
    <v-dialog v-model="dialog" max-width="400">
      <v-card>
        <v-card-title>Create Photo Card</v-card-title>
        <v-card-text>
          <v-form>
            <v-text-field v-model="photo.albumId" label="User Id"></v-text-field>

            <v-text-field v-model="photo.title" label="Title"></v-text-field>
            
            <v-text-field v-model="photo.url" label="Url"></v-text-field>

          </v-form>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="green" @click="savePhoto"> Save </v-btn>
          <v-btn color="primary" @click="dialog=false">Cancel</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script>
import http from "./utils/http"
import ImageCards from "./components/ImageCards.vue";
 export default {
  name: "App",
  components: {
    ImageCards,
  },
  data() {
    return {
      dialog: false,
      photo: {
        id: null,
        albumId: '',
        title: '',
        url: ''
      },
      photos: [],
    };
  },
  async mounted() {
    const response = await http.get("/photos?_page=0&_sort=id&_order=desc");
    this.photos = response.data;
  },
    methods: {
    openDialog() {
      this.dialog = true;
    },
    async savePhoto() {
        await http.post('/photos', {
        albumId: this.photo.albumId,
        title: this.photo.title,
        url: this.photo.url
      })
      this.photo = {
        id: null,
        albumId: '',
        title: '',
        url: ''
      }
      this.dialog = false
    },
  },
  }
</script>